Python 3.7.2 (tags/v3.7.2:9a3ffc0492, Dec 23 2018, 22:20:52) [MSC v.1916 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> a=range(2019,2119)
>>> for b in a:
	if b%4==0:
		print(b)

		
2020
2024
2028
2032
2036
2040
2044
2048
2052
2056
2060
2064
2068
2072
2076
2080
2084
2088
2092
2096
2100
2104
2108
2112
2116
>>> student1={"Name":"Amini Amina","Y.O.B":1980}
>>> student2={"Name":"Imini Amina","Y.O.B":1990}
>>> student3={"Name":"Ikina bado","Y.O.B":1995}
>>> student4={"Name":"Hamna haya","Y.O.B":1997}
>>> student5={"Name":"Mambo bado","Y.O.B":1999}
>>> students=[student1,student2,student3,student4,student5]
>>> for student in students:
	days=(2019-student["Y.O.B"])*365
print("Hello{}, you are {}  old.".format(student["Name"],days))
SyntaxError: invalid syntax
>>> for student in students:
	days=(2019-student["Y.O.B"])*365
			print("Hello {}, you are {}  old.".format(student["Name"],days))
			
SyntaxError: unexpected indent
>>> for student in students:
	days=(2019-student["Y.O.B"])*365
	print("Hello {},you are {} old.".format(student["Name"],days))

	
Hello Amini Amina,you are 14235 old.
Hello Imini Amina,you are 10585 old.
Hello Ikina bado,you are 8760 old.
Hello Hamna haya,you are 8030 old.
Hello Mambo bado,you are 7300 old.
>>> 
